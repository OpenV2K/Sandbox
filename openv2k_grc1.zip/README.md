# Voice Zero-Crossing Pulse Transmitter — GNU Radio Module

Captures microphone audio, conditions it for speech, detects every zero-crossing,
and emits a configurable-width pulse stream through a HackRF One via the osmocom sink.

---

## Files

| File | Purpose |
|---|---|
| `voice_pulse_tx.grc` | Open in GNU Radio Companion to edit / run visually |
| `zero_cross_pulse.py` | Standalone Python class; also the source for the embedded Python block |

---

## Dependencies

```
GNU Radio  ≥ 3.10          (gr-osmosdr must be built against GR 3.10)
gr-osmosdr                  sudo apt install gr-osmosdr  OR  build from source
hackrf tools                sudo apt install hackrf
PyQt5                       sudo apt install python3-pyqt5
```

Verify HackRF is recognised before running:

```bash
hackrf_info
```

---

## Running

```bash
# Option 1 – GUI editor
gnuradio-companion voice_pulse_tx.grc

# Option 2 – generate and run from GRC (File > Generate, then Run)
# Option 3 – run the generated Python directly after generating
python3 voice_pulse_tx.py
```

---

## Signal Chain

```
Microphone
    │
    ▼
┌─────────────────┐   48 000 Hz float stream
│  Audio Source   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   DC Blocker    │   Removes static DC offset; prevents zero-crossing bias
│   (64-tap IIR)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  High-Pass FIR  │◄── GUI slider: 250 – 1 000 Hz  (default 300 Hz)
│   (Hamming)     │   Removes: room rumble, wind noise, mains hum, plosives
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Low-Pass FIR   │◄── GUI slider: 1 000 – 15 000 Hz  (default 3 400 Hz)
│   (Hamming)     │   Removes: hiss, sibilance, noise above voice band
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│      AGC        │   Normalises amplitude so soft speakers get the
│  (analog_agc)   │   same pulse density as loud ones
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Zero-Crossing  │◄── GUI slider: 50 – 500 µs  (default 100 µs)
│  Pulse Gen      │   Emits 1.0 pulse at every sign change of the signal
│  (epy_block)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Multiply Const  │◄── GUI slider: 0.0 – 1.0  (TX amplitude)
└────────┬────────┘
         │
         ▼
┌─────────────────────────────┐
│  Rational Resampler         │   48 000 → 2 000 000 Hz
│  interp=125  decim=3  (fff) │   (48 000 × 125 / 3 = 2 000 000 exactly)
└────────────────┬────────────┘
                 │
                 ▼
┌─────────────────┐   ┌──────────────┐
│ Float-to-Complex│◄──│  Null Source │ (zero imaginary channel)
└────────┬────────┘   └──────────────┘
         │
         ▼
┌─────────────────┐
│  HackRF Sink    │   Centre freq via GUI slider  (default 433.92 MHz)
│ (osmosdr_sink)  │   IF gain 40 dB, BB gain 20 dB, RF amp OFF
└─────────────────┘
```

---

## GUI Controls

| Widget | Range | Default | Purpose |
|---|---|---|---|
| Pulse Width (µs) | 50 – 500 µs | 100 µs | Duration of each zero-crossing pulse |
| LPF Cutoff (Hz) | 1 000 – 15 000 Hz | 3 400 Hz | Low-pass voice ceiling |
| HPF Cutoff (Hz) | 250 – 1 000 Hz | 300 Hz | High-pass voice floor |
| Centre Freq (Hz) | 70 MHz – 6 GHz | 433.92 MHz | HackRF carrier frequency |
| TX Amplitude | 0.0 – 1.0 | 0.8 | Output signal scale |

---

## Monitoring Displays (tab "Monitoring")

**Voice Spectrum** — FFT of the filtered voice signal (before pulse generation).
Use this to verify the HPF/LPF is shaping the spectrum as intended.

**Pulse Waveform** — Overlay of the pulse output (blue) and conditioned voice (red).
The blue pulses should visually align with the red waveform zero-crossings.

---

## Additional Filters Recommended for Voice

These are not in the default flowgraph but are easy to add from the GRC block browser.

### 1. Band-Pass Convenience Block  (`band_pass_filter`)
A single block that combines the HPF + LPF into one design step.
Use `low = 300 Hz`, `high = 3 400 Hz`, transition 100 Hz each side.
Yields a tighter passband for telephone-quality speech.

### 2. Noise Gate / Squelch  (`analog_simple_squelch_cc` or `analog_pwr_squelch_ff`)
Silences the output when the speaker is not talking, preventing random noise
pulses in quiet periods.  Set the threshold just above the ambient noise floor
visible on the spectrum display.

### 3. Pre-emphasis Filter  (`iir_filter_ffd`)
Boosts frequencies above ~1 kHz by approximately +6 dB/octave.
This counteracts the natural fall-off of vocal formants, making consonants
crisper, and improves zero-crossing density in the higher harmonics.

Coefficients for a simple single-pole pre-emphasis shelf at 1 kHz / 48 kHz:
```
fwd_taps = [1.0, -0.9375]
rev_taps = [1.0]
```

### 4. De-emphasis (listener end) 
The inverse of pre-emphasis — apply on the receiver side to restore flat
frequency response after any channel de-emphasis.  Coefficients are
reciprocal of the pre-emphasis shelf.

### 5. Notch Filter at 50/60 Hz  (`band_reject_filter`)
If you use the HPF below 100 Hz, a narrow IIR notch at your mains frequency
is more efficient than a wide FIR band-reject.
Use an IIR biquad (Q ≈ 30) for a minimal-tap implementation:
```python
# Example biquad for 60 Hz at 48 000 Hz
# Build with scipy.signal.iirnotch and feed into iir_filter_ffd
from scipy.signal import iirnotch
b, a = iirnotch(60, Q=30, fs=48000)
```

### 6. Voice-Activity Detection / Envelope Follower  (`blocks_moving_average_xx`)
Run a short moving-average (≈ 10 ms) over the absolute value of the AGC
output. Use the result to gate the zero-crossing block or adjust pulse
width dynamically — wider pulses when speech is weak, narrower when strong.

### 7. Spectral Subtraction / Noise Reduction  (custom `epy_block`)
For noisy environments: estimate the noise floor during silence (squelch
gate OFF), then subtract it from the power spectrum each frame using an FFT
→ suppress → IFFT chain. This requires a custom embedded Python block.

---

## HackRF Gain Settings

| Parameter | Recommended Range | Notes |
|---|---|---|
| RF Amp (`gain0`) | 0 or 14 dB | Use 0 unless you need extra range; adds noise |
| IF Gain (`if_gain0`) | 16 – 47 dB (step 8) | Primary gain control |
| BB Gain (`bb_gain0`) | 0 – 62 dB (step 2) | Fine-tune; keep below clipping |

Start with RF=0, IF=40, BB=20 and adjust BB up or down to avoid IMD.

---

## Pulse Width vs. Voice Frequency

At the default 48 kHz sample rate:

| Pulse Width | Samples | Highest clean pitch (Nyquist) |
|---|---|---|
| 50 µs | 2–3 | ~24 000 Hz |
| 100 µs | 4–5 | ~10 000 Hz |
| 250 µs | 12 | ~4 000 Hz |
| 500 µs | 24 | ~2 000 Hz |

Narrower pulses carry more high-frequency spectral content.
For voice (300–3 400 Hz fundamental), 100–200 µs is a good starting point.

---

## Troubleshooting

**No audio**: Check the system default microphone; change `device_name` in the
Audio Source block to a specific ALSA/PulseAudio device name.

**HackRF not found**: Run `hackrf_info`. If it shows the device, check the
`args` parameter of the osmocom sink: `"hackrf=0"` selects the first HackRF.

**Overflows / underruns**: Reduce `samp_rate_hackrf` to 1 000 000 Hz and adjust
the rational resampler to `interp=125, decim=6` (→ 1 MHz).

**Too many pulses / noise pulses**: Raise the HPF cutoff to 500 Hz and enable
the squelch block to blank output during silence.

**Filter lag / audio dropout**: Hamming-window FIR filters with wide transition
bands have moderate tap counts. If CPU load is high, switch `win` to
`window.WIN_RECTANGULAR` (fewest taps, worst stopband) or decimate the audio
stream early and operate the entire chain at a lower rate.
