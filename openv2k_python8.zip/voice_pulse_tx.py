#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# SPDX-License-Identifier: Unlicense
# This is free and unencumbered software released into the public domain.
#
# OpenV2K -- Voice Zero-Crossing Pulse Transmitter
# =================================================
# Requirements:
#   sudo apt install gnuradio gr-osmosdr hackrf python3-pyqt5
# Usage:
#   python3 voice_pulse_tx.py

import sys
import math
import signal
import subprocess
import datetime
import numpy as np

# -- GNU Radio imports --------------------------------------------------------
from gnuradio import gr, audio, analog, blocks
from gnuradio import filter as gr_filter
from gnuradio.filter import firdes

try:
    from gnuradio.fft import window as gr_window
    _WIN_HAMMING = gr_window.WIN_HAMMING
except (ImportError, AttributeError):
    _WIN_HAMMING = firdes.WIN_HAMMING

import osmosdr

# -- Qt imports ---------------------------------------------------------------
try:
    from PyQt5 import QtWidgets, QtCore, QtGui
except ImportError:
    sys.exit("PyQt5 required: sudo apt install python3-pyqt5")


# =============================================================================
#  HackRF hardware detection
# =============================================================================

def detect_hackrf():
    """
    Run hackrf_info and return (found: bool, info_string: str).
    Parses serial number and firmware version for display.
    """
    try:
        result = subprocess.run(
            ['hackrf_info'],
            capture_output=True, text=True, timeout=5)
        # hackrf_info writes to stdout on some builds, stderr on others
        output = result.stdout + result.stderr
        if 'HackRF' in output and result.returncode == 0:
            lines = output.splitlines()
            firmware = next(
                (l.split(': ', 1)[1].strip() for l in lines
                 if 'Firmware Version' in l), 'unknown')
            return True, "HackRF One found\nFW: {}".format(firmware)
        return False, output.strip().splitlines()[0] if output.strip() \
            else "HackRF not found"
    except FileNotFoundError:
        return False, "hackrf_info not found -- sudo apt install hackrf"
    except subprocess.TimeoutExpired:
        return False, "hackrf_info timed out -- check USB connection"
    except Exception as e:
        return False, "Detection error: {}".format(e)


# =============================================================================
#  Zero-Crossing Pulse Generator (GNU Radio sync block)
# =============================================================================

class ZeroCrossPulse(gr.sync_block):
    """
    Emits a 1.0 pulse of pulse_width_us microseconds on every zero-crossing
    (rising AND falling) of a float32 audio stream.
    """

    def __init__(self, sample_rate=48000.0, pulse_width_us=100.0):
        gr.sync_block.__init__(
            self, name="Zero Cross Pulse",
            in_sig=[np.float32], out_sig=[np.float32])
        self._sr    = float(sample_rate)
        self._pw_us = float(pulse_width_us)
        self._last  = 0.0
        self._rem   = 0
        self._recompute()

    def set_pulse_width_us(self, v):
        self._pw_us = float(v)
        self._recompute()

    def set_sample_rate(self, v):
        self._sr = float(v)
        self._recompute()

    def _recompute(self):
        self._plen = max(1, int(round(self._sr * self._pw_us * 1e-6)))

    def work(self, input_items, output_items):
        in0, out        = input_items[0], output_items[0]
        last, rem, plen = self._last, self._rem, self._plen
        for i in range(len(in0)):
            curr = float(in0[i])
            if (last < 0.0 <= curr) or (last >= 0.0 > curr):
                rem = plen
            out[i] = 1.0 if rem > 0 else 0.0
            if rem > 0:
                rem -= 1
            last = curr
        self._last, self._rem = last, rem
        return len(in0)


# =============================================================================
#  Simple Noise Gate (GNU Radio sync block)
# =============================================================================

class SimpleNoiseGate(gr.sync_block):
    """
    Gates the audio stream: when short-term power falls below threshold_db
    the output is zeroed, suppressing noise between words.
    Safe to call set_enabled() and set_threshold_db() while running.
    """

    def __init__(self, threshold_db=-30.0, window=480):
        gr.sync_block.__init__(self, name="Noise Gate",
                               in_sig=[np.float32], out_sig=[np.float32])
        self._enabled  = False
        self._alpha    = 1.0 / max(1, window)   # smoothing coefficient
        self._power    = 0.0
        self.set_threshold_db(threshold_db)

    def set_enabled(self, enabled):
        self._enabled = bool(enabled)

    def set_threshold_db(self, db):
        self._thresh = 10.0 ** (float(db) / 10.0)

    def work(self, input_items, output_items):
        in0, out = input_items[0], output_items[0]
        if not self._enabled:
            out[:] = in0
            return len(in0)
        alpha  = self._alpha
        thresh = self._thresh
        power  = self._power
        for i in range(len(in0)):
            s = float(in0[i])
            power = (1.0 - alpha) * power + alpha * s * s
            out[i] = s if power >= thresh else 0.0
        self._power = power
        return len(in0)


# =============================================================================
#  Audio level meter widget
# =============================================================================

class LevelMeter(QtWidgets.QWidget):
    """
    Horizontal dB VU meter with colour gradient and numeric readout.
    Call set_level_db(db) to update. Range: -60 dB (silence) to 0 dB (clip).
    Green: -60 to -18 dB | Amber: -18 to -6 dB | Red: -6 to 0 dB
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        vbox = QtWidgets.QVBoxLayout(self)
        vbox.setContentsMargins(0, 2, 0, 2)
        vbox.setSpacing(1)

        # Colour-gradient progress bar
        self._bar = QtWidgets.QProgressBar()
        self._bar.setRange(0, 600)          # 0.1 dB resolution over 60 dB
        self._bar.setValue(0)
        self._bar.setTextVisible(False)
        self._bar.setFixedHeight(18)
        self._bar.setStyleSheet(
            "QProgressBar {"
            "  border: 1px solid #444;"
            "  background: #1a1a1a;"
            "  border-radius: 3px;"
            "}"
            "QProgressBar::chunk {"
            "  background: qlineargradient("
            "    x1:0, y1:0, x2:1, y2:0,"
            "    stop:0.00 #27ae60,"   # green  -60 dB
            "    stop:0.70 #27ae60,"   # green  -18 dB
            "    stop:0.80 #f39c12,"   # amber  -6 dB
            "    stop:0.90 #f39c12,"
            "    stop:1.00 #e74c3c"    # red     0 dB
            "  );"
            "  border-radius: 3px;"
            "}"
        )
        vbox.addWidget(self._bar)

        # Scale labels row
        scale = QtWidgets.QHBoxLayout()
        scale.setContentsMargins(0, 0, 0, 0)
        for txt, align in [("-60", QtCore.Qt.AlignLeft),
                            ("-30", QtCore.Qt.AlignCenter),
                            ("0 dB", QtCore.Qt.AlignRight)]:
            lbl = QtWidgets.QLabel(txt)
            lbl.setFont(QtGui.QFont("Monospace", 7))
            lbl.setStyleSheet("color: #888;")
            lbl.setAlignment(align)
            scale.addWidget(lbl)
        vbox.addLayout(scale)

        # Numeric readout
        self._readout = QtWidgets.QLabel("---  dB")
        self._readout.setFont(QtGui.QFont("Monospace", 8))
        self._readout.setAlignment(QtCore.Qt.AlignCenter)
        self._readout.setStyleSheet("color: #aaa;")
        vbox.addWidget(self._readout)

    def set_level_db(self, db):
        db = max(-60.0, min(0.0, db))
        self._bar.setValue(int((db + 60.0) * 10.0))
        self._readout.setText("{:+.1f} dB".format(db))
        # Colour the readout text to match the zone
        if db > -6.0:
            colour = "#e74c3c"
        elif db > -18.0:
            colour = "#f39c12"
        else:
            colour = "#27ae60"
        self._readout.setStyleSheet("color: {};".format(colour))


# =============================================================================
#  Labelled slider widget with tick marks
# =============================================================================

class LabelledSlider(QtWidgets.QWidget):
    """
    Compact horizontal slider with label, tick marks, and readout.
    tick_steps: number of slider integer steps between each visible tick.
    """

    def __init__(self, label, lo, hi, step, default,
                 fmt="{:.0f}", callback=None, tick_steps=10, parent=None):
        super().__init__(parent)
        self._lo   = float(lo)
        self._step = float(step)
        self._fmt  = fmt
        self._cb   = callback

        n_steps = max(1, int(round((hi - lo) / step)))

        self._slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self._slider.setRange(0, n_steps)
        self._slider.setValue(int(round((default - lo) / step)))
        self._slider.setMinimumWidth(160)
        self._slider.setMaximumWidth(220)
        self._slider.setTickPosition(QtWidgets.QSlider.TicksBelow)
        self._slider.setTickInterval(tick_steps)

        self._readout = QtWidgets.QLabel(fmt.format(default))
        self._readout.setMinimumWidth(72)
        self._readout.setAlignment(
            QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        self._readout.setFont(QtGui.QFont("Monospace", 8))

        lbl = QtWidgets.QLabel("<b>{}</b>".format(label))
        lbl.setMinimumWidth(100)
        lbl.setMaximumWidth(110)

        row = QtWidgets.QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        row.addWidget(lbl)
        row.addWidget(self._slider)
        row.addWidget(self._readout)

        self._slider.valueChanged.connect(self._on_change)

    def _on_change(self, pos):
        val = self._lo + pos * self._step
        self._readout.setText(self._fmt.format(val))
        if self._cb:
            self._cb(val)

    def value(self):
        return self._lo + self._slider.value() * self._step


# =============================================================================
#  Top Block (GNU Radio flow graph + Qt main window)
# =============================================================================

class VoicePulseTX(gr.top_block, QtWidgets.QMainWindow):
    """
    GNU Radio top-block and Qt main window.
    Layout (top to bottom): Audio Input -> Signal Processing -> SDR Output.
    Launches with microphone muted and TX disabled.
    """

    AUDIO_RATE    = 48000
    HACKRF_RATE   = 2000000     # 48000 * 125 / 3 = 2000000 exactly
    RESAMP_INTERP = 125
    RESAMP_DECIM  = 3

    FREQ_70CM = 425e6           # 70cm UHF amateur band
    FREQ_23CM = 1300e6          # 23cm amateur band / L-band

    # Power: P proportional to amplitude^2, so AMP_2MW = sqrt(2) * AMP_1MW
    AMP_1MW = 0.500
    AMP_2MW = 0.707

    def __init__(self):
        gr.top_block.__init__(self, "VoicePulseTX", catch_exceptions=True)
        QtWidgets.QMainWindow.__init__(self)

        _today = datetime.date.today()
        self.setWindowTitle(
            "OpenV2K ({}/{}/{})".format(
                _today.year, _today.month, _today.day))
        self.setFixedWidth(450)

        # -- Detect HackRF before building anything -----------------------
        self._hackrf_found, self._hackrf_info = detect_hackrf()

        # -- Runtime state (starts muted and TX disabled) -----------------
        self._pulse_us   = 100.0
        self._hpf_hz     = 300.0
        self._lpf_hz     = 3400.0
        self._freq_hz    = self.FREQ_23CM
        self._amplitude  = self.AMP_1MW
        self._muted      = True     # <-- starts muted
        self._tx_enabled = False    # <-- starts TX disabled

        self._build_gui()
        self._build_blocks()
        self._connect_blocks()

        # Level meter polling timer (10 Hz)
        self._level_timer = QtCore.QTimer()
        self._level_timer.timeout.connect(self._update_level_meter)
        self._level_timer.start(100)

    # =========================================================================
    #  GUI
    # =========================================================================

    def _build_gui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        vbox = QtWidgets.QVBoxLayout(central)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(8)

        # Title
        title = QtWidgets.QLabel(
            "<h3 style='color:#2a6ebb; margin:0;'>OpenV2K</h3>"
            "<small>Voice Zero-Crossing Pulse TX</small>")
        title.setAlignment(QtCore.Qt.AlignCenter)
        vbox.addWidget(title)
        vbox.addWidget(self._hline())

        # =================================================================
        # Section 1: Audio Input
        # =================================================================
        vbox.addWidget(QtWidgets.QLabel("<b>Audio Input</b>"))

        # Microphone mute toggle (starts muted = checked)
        self._btn_mute = QtWidgets.QPushButton("Mic: MUTED")
        self._btn_mute.setCheckable(True)
        self._btn_mute.setChecked(True)
        self._btn_mute.setMinimumHeight(34)
        self._btn_mute.setStyleSheet(self._style_red())
        self._btn_mute.toggled.connect(self._cb_mute)
        vbox.addWidget(self._btn_mute)

        # Audio level meter
        meter_lbl = QtWidgets.QLabel(
            "Mic Input Level  |  silence floor: -45 dB or lower  "
            "|  voice peaks: aim for -18 dB\n"
            "Adjust in System Settings > Sound > Input Volume "
            "while watching this meter.")
        meter_lbl.setStyleSheet("color: #aaa; font-size: 10px;")
        meter_lbl.setWordWrap(True)
        vbox.addWidget(meter_lbl)

        self._level_meter = LevelMeter()
        vbox.addWidget(self._level_meter)

        vbox.addWidget(self._hline())
        vbox.addSpacing(7)

        # =================================================================
        # Section 2: Signal Processing
        # =================================================================
        vbox.addWidget(QtWidgets.QLabel("<b>Signal Processing</b>"))

        # Pulse width: 50-500 us, step 5 us, tick every 50 us = 10 steps
        self._sl_pulse = LabelledSlider(
            "Pulse (us)", 50, 500, 5, self._pulse_us,
            fmt="{:.0f} us", callback=self._cb_pulse, tick_steps=10)
        vbox.addWidget(self._sl_pulse)

        # HPF: 250-1000 Hz, step 10 Hz, tick every 100 Hz = 10 steps
        self._sl_hpf = LabelledSlider(
            "HPF (Hz)", 250, 1000, 10, self._hpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_hpf, tick_steps=10)
        vbox.addWidget(self._sl_hpf)

        # LPF: 1000-15000 Hz, step 100 Hz, tick every 500 Hz = 5 steps
        self._sl_lpf = LabelledSlider(
            "LPF (Hz)", 1000, 15000, 100, self._lpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_lpf, tick_steps=5)
        vbox.addWidget(self._sl_lpf)

        # Optional filters group
        opt_box = QtWidgets.QGroupBox("Optional Filters")
        opt_layout = QtWidgets.QVBoxLayout()
        opt_layout.setSpacing(4)

        self._chk_notch = QtWidgets.QCheckBox(
            "50/60 Hz Mains Notch  -- removes hum from power lines")
        self._chk_notch.setChecked(False)
        self._chk_notch.toggled.connect(self._toggle_notch)
        opt_layout.addWidget(self._chk_notch)

        self._chk_preemph = QtWidgets.QCheckBox(
            "Pre-emphasis  -- +6 dB/oct above 1 kHz, sharpens consonants")
        self._chk_preemph.setChecked(False)
        self._chk_preemph.toggled.connect(self._toggle_preemph)
        opt_layout.addWidget(self._chk_preemph)

        self._chk_noisegate = QtWidgets.QCheckBox(
            "Noise Gate  -- zeros output below -30 dB, kills inter-word noise")
        self._chk_noisegate.setChecked(False)
        self._chk_noisegate.toggled.connect(self._toggle_noisegate)
        opt_layout.addWidget(self._chk_noisegate)

        opt_box.setLayout(opt_layout)
        vbox.addWidget(opt_box)

        # Duty cycle readout -- rolling 1-second average of pulse output
        dc_row = QtWidgets.QHBoxLayout()
        dc_lbl = QtWidgets.QLabel("Pulse Duty Cycle:")
        dc_lbl.setStyleSheet("color: #aaa; font-size: 10px;")
        self._dc_readout = QtWidgets.QLabel("--.-  %")
        self._dc_readout.setFont(QtGui.QFont("Monospace", 9))
        self._dc_readout.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        dc_row.addWidget(dc_lbl)
        dc_row.addStretch()
        dc_row.addWidget(self._dc_readout)
        vbox.addLayout(dc_row)

        vbox.addWidget(self._hline())
        vbox.addSpacing(7)

        # =================================================================
        # Section 3: SDR Output Transmitter
        # =================================================================
        # Header row: section title on left, HackRF status on right
        header_row = QtWidgets.QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)

        tx_header = QtWidgets.QLabel(
            "<b>Transmitter</b><br>"
            "<span style='font-size:10px; color:#aaa;'>HackRF SDR Output</span>")
        header_row.addWidget(tx_header)

        hw_lbl = QtWidgets.QLabel(self._hackrf_info)
        hw_lbl.setFont(QtGui.QFont("Monospace", 8))
        hw_lbl.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        if self._hackrf_found:
            hw_lbl.setStyleSheet("color: #27ae60;")
        else:
            hw_lbl.setStyleSheet("color: #e74c3c;")
        header_row.addWidget(hw_lbl)

        vbox.addLayout(header_row)

        # SDR controls container -- greyed out if no HackRF
        self._sdr_controls = QtWidgets.QWidget()
        sdr_vbox = QtWidgets.QVBoxLayout(self._sdr_controls)
        sdr_vbox.setContentsMargins(0, 0, 0, 0)
        sdr_vbox.setSpacing(6)

        # Frequency toggle
        freq_box = QtWidgets.QGroupBox("Frequency")
        freq_layout = QtWidgets.QHBoxLayout()
        freq_layout.setSpacing(8)
        self._rb_70cm = QtWidgets.QRadioButton("425 MHz  (70cm)")
        self._rb_23cm = QtWidgets.QRadioButton("1300 MHz (23cm)")
        self._rb_23cm.setChecked(True)
        self._rb_70cm.toggled.connect(self._cb_freq_toggle)
        freq_layout.addWidget(self._rb_70cm)
        freq_layout.addWidget(self._rb_23cm)
        freq_box.setLayout(freq_layout)
        sdr_vbox.addWidget(freq_box)

        # Power toggle
        pwr_box = QtWidgets.QGroupBox("TX Power (relative)")
        pwr_layout = QtWidgets.QHBoxLayout()
        pwr_layout.setSpacing(8)
        self._rb_1mw = QtWidgets.QRadioButton("1 mW")
        self._rb_2mw = QtWidgets.QRadioButton("2 mW")
        self._rb_1mw.setChecked(True)
        self._rb_1mw.toggled.connect(self._cb_pwr_toggle)
        pwr_layout.addWidget(self._rb_1mw)
        pwr_layout.addWidget(self._rb_2mw)
        pwr_box.setLayout(pwr_layout)
        sdr_vbox.addWidget(pwr_box)

        # TX enable toggle (starts disabled = checked)
        sdr_vbox.addSpacing(7)
        self._btn_tx = QtWidgets.QPushButton("TX: DISABLED")
        self._btn_tx.setCheckable(True)
        self._btn_tx.setChecked(True)
        self._btn_tx.setMinimumHeight(34)
        self._btn_tx.setStyleSheet(self._style_red())
        self._btn_tx.toggled.connect(self._cb_tx_toggle)
        sdr_vbox.addWidget(self._btn_tx)

        vbox.addWidget(self._sdr_controls)

        # Disable entire SDR section if no HackRF detected
        if not self._hackrf_found:
            self._sdr_controls.setEnabled(False)
            no_hw = QtWidgets.QLabel(
                "Connect HackRF via USB data cable and restart.")
            no_hw.setStyleSheet("color: #888; font-size: 10px;")
            no_hw.setWordWrap(True)
            vbox.addWidget(no_hw)

        vbox.addStretch()

    # -- Style helpers --------------------------------------------------------

    @staticmethod
    def _style_green():
        return ("QPushButton { background-color: #27ae60; color: white;"
                " border-radius: 4px; font-weight: bold; }"
                "QPushButton:hover { background-color: #2ecc71; }")

    @staticmethod
    def _style_red():
        return ("QPushButton { background-color: #c0392b; color: white;"
                " border-radius: 4px; font-weight: bold; }"
                "QPushButton:hover { background-color: #e74c3c; }")

    @staticmethod
    def _hline():
        f = QtWidgets.QFrame()
        f.setFrameShape(QtWidgets.QFrame.HLine)
        f.setFrameShadow(QtWidgets.QFrame.Sunken)
        return f

    # =========================================================================
    #  GNU Radio blocks
    # =========================================================================

    def _build_blocks(self):
        sr = self.AUDIO_RATE

        # 1. Microphone
        self.audio_src = audio.source(sr, "", True)

        # 2. Level probe -- taps raw mic signal BEFORE the mute gate
        #    so the meter always shows whether the mic is picking up audio.
        #    Alpha 1e-3 -> ~20 ms averaging time constant.
        self.level_probe = analog.probe_avg_mag_sqrd_f(0, 1e-3)

        # 2b. Duty cycle probe -- taps ZCP output (values are 0.0 or 1.0)
        #     avg(|x|^2) = avg(x) = fraction of time output is 1 = duty cycle.
        #     Alpha 2e-5 -> ~1 second rolling average for a stable reading.
        self.dc_probe = analog.probe_avg_mag_sqrd_f(0, 2e-5)

        # 3. Mute gate -- set_k(0.0) silences stream, set_k(1.0) passes it
        #    Starts at 0.0 (muted)
        self.mute_gate = blocks.multiply_const_ff(0.0)

        # 4. DC blocker IIR: H(z) = (1 - z^-1) / (1 - 0.999*z^-1)
        #    fftaps = feedforward numerator
        #    fbtaps = feedback denominator (oldstyle=True, no leading 1)
        self.dc_blocker = gr_filter.iir_filter_ffd(
            [1.0, -1.0], [-0.999], True)

        # 5. High-pass filter (variable cutoff via slider)
        self.hpf = gr_filter.fir_filter_fff(
            1,
            firdes.high_pass(
                1, sr, self._hpf_hz,
                transition_width=50,
                window=_WIN_HAMMING, param=6.76))

        # 6. Low-pass filter (variable cutoff via slider)
        self.lpf = gr_filter.fir_filter_fff(
            1,
            firdes.low_pass(
                1, sr, self._lpf_hz,
                transition_width=200,
                window=_WIN_HAMMING, param=6.76))

        # 7a. Mains notch (50/60 Hz biquad IIR, starts as passthrough)
        #     Passthrough: fftaps=[1], fbtaps=[0] -> y[n] = x[n]
        _f0  = 60.0                              # change to 50.0 for EU mains
        _Q   = 30.0
        _w0  = 2.0 * math.pi * _f0 / float(sr)
        _al  = math.sin(_w0) / (2.0 * _Q)
        _cw  = math.cos(_w0)
        _a0  = 1.0 + _al
        self._notch_b = [1.0/_a0, -2.0*_cw/_a0, 1.0/_a0]
        self._notch_a = [-2.0*_cw/_a0, (1.0-_al)/_a0]
        self.notch = gr_filter.iir_filter_ffd([1.0], [0.0], True)

        # 7b. Pre-emphasis FIR shelf (starts as passthrough)
        #     Active taps [1.0, -0.9375]: first-difference +6 dB/oct above ~1.5 kHz
        self.pre_emph = gr_filter.fir_filter_fff(1, [1.0])

        # 7c. Noise gate (custom block, disabled at start -- passes all signal)
        self.noise_gate = SimpleNoiseGate(threshold_db=-30.0, window=480)

        # 8. AGC
        self.agc = analog.agc_ff(1e-4, 0.5, 1.0)
        self.agc.set_max_gain(65536)

        # 9. Zero-crossing pulse generator
        self.zcp = ZeroCrossPulse(sr, self._pulse_us)

        # 9. Amplitude scaler
        self.mult = blocks.multiply_const_ff(self._amplitude)

        # 10. Rational resampler: 48000 -> 2000000 Hz
        self.resampler = gr_filter.rational_resampler_fff(
            interpolation=self.RESAMP_INTERP,
            decimation=self.RESAMP_DECIM,
            taps=[],
            fractional_bw=0.0)

        # 11. Null source for Q channel
        self.null_src = blocks.null_source(gr.sizeof_float)

        # 12. Float -> Complex IQ
        self.f2c = blocks.float_to_complex(1)

        # 13. TX gate: (0+0j) = silent carrier, (1+0j) = transmit
        #     Starts at (0+0j) -- TX disabled
        self.tx_gate = blocks.multiply_const_cc((0+0j))

        # 14. HackRF sink (or null sink if hardware not found)
        if self._hackrf_found:
            self.hackrf = osmosdr.sink(args="numchan=1 hackrf=0")
            self.hackrf.set_sample_rate(self.HACKRF_RATE)
            self.hackrf.set_center_freq(self._freq_hz, 0)
            self.hackrf.set_freq_corr(0, 0)
            self.hackrf.set_gain(0, 0)       # RF amp OFF
            self.hackrf.set_if_gain(40, 0)   # 0-47 dB, steps of 8
            self.hackrf.set_bb_gain(20, 0)   # 0-62 dB, steps of 2
            self.hackrf.set_antenna("", 0)
            self.hackrf.set_bandwidth(0, 0)
        else:
            # No hardware -- use null sink so audio chain still runs
            self.hackrf = blocks.null_sink(gr.sizeof_gr_complex)

    def _connect_blocks(self):
        # Fan-out from audio_src:
        #   port 0 -> mute_gate (main processing chain)
        #   port 0 -> level_probe (meter, always sees raw mic)
        self.connect(self.audio_src, self.mute_gate)
        self.connect(self.audio_src, self.level_probe)

        # Main processing chain
        self.connect(self.mute_gate,  self.dc_blocker)
        self.connect(self.dc_blocker, self.notch)       # optional: mains notch
        self.connect(self.notch,      self.hpf)
        self.connect(self.hpf,        self.lpf)
        self.connect(self.lpf,        self.pre_emph)    # optional: pre-emphasis
        self.connect(self.pre_emph,   self.agc)
        self.connect(self.agc,        self.noise_gate)  # optional: noise gate
        self.connect(self.noise_gate, self.zcp)
        self.connect(self.zcp,        self.mult)
        self.connect(self.zcp,        self.dc_probe)    # duty cycle tap
        self.connect(self.mult,       self.resampler)
        self.connect(self.resampler,  (self.f2c, 0))
        self.connect(self.null_src,   (self.f2c, 1))
        self.connect(self.f2c,        self.tx_gate)
        self.connect(self.tx_gate,    self.hackrf)

    # =========================================================================
    #  Display update (called by QTimer at 10 Hz)
    # =========================================================================

    def _update_level_meter(self):
        # Audio input level
        mag_sq = self.level_probe.level()
        if mag_sq > 1e-12:
            db = 10.0 * math.log10(mag_sq)
        else:
            db = -60.0
        self._level_meter.set_level_db(db)

        # Pulse duty cycle  (ZCP output is 0 or 1, so avg(x^2) = avg(x) = duty)
        duty_frac = max(0.0, min(1.0, self.dc_probe.level()))
        self._dc_readout.setText("{:5.1f}  %".format(duty_frac * 100.0))

    # =========================================================================
    #  Slider callbacks
    # =========================================================================

    def _cb_pulse(self, v):
        self._pulse_us = v
        self.zcp.set_pulse_width_us(v)

    def _cb_hpf(self, v):
        self._hpf_hz = v
        self.hpf.set_taps(firdes.high_pass(
            1, self.AUDIO_RATE, v,
            transition_width=50,
            window=_WIN_HAMMING, param=6.76))

    def _cb_lpf(self, v):
        self._lpf_hz = v
        self.lpf.set_taps(firdes.low_pass(
            1, self.AUDIO_RATE, v,
            transition_width=200,
            window=_WIN_HAMMING, param=6.76))

    # =========================================================================
    #  Optional filter toggle callbacks
    # =========================================================================

    def _toggle_notch(self, enabled):
        """Switch the 50/60 Hz IIR notch between active and passthrough."""
        if enabled:
            self.notch.set_taps(self._notch_b, self._notch_a)
        else:
            self.notch.set_taps([1.0], [0.0])

    def _toggle_preemph(self, enabled):
        """Switch pre-emphasis FIR between shelf and flat passthrough."""
        if enabled:
            self.pre_emph.set_taps([1.0, -0.9375])
        else:
            self.pre_emph.set_taps([1.0])

    def _toggle_noisegate(self, enabled):
        """Enable or disable the noise gate."""
        self.noise_gate.set_enabled(enabled)

    # =========================================================================
    #  Toggle callbacks
    # =========================================================================

    def _cb_freq_toggle(self, is_70cm):
        self._freq_hz = self.FREQ_70CM if is_70cm else self.FREQ_23CM
        if self._hackrf_found:
            self.hackrf.set_center_freq(self._freq_hz, 0)

    def _cb_pwr_toggle(self, is_1mw):
        self._amplitude = self.AMP_1MW if is_1mw else self.AMP_2MW
        self.mult.set_k(self._amplitude)

    def _cb_mute(self, muted):
        self._muted = muted
        self.mute_gate.set_k(0.0 if muted else 1.0)
        if muted:
            self._btn_mute.setText("Mic: MUTED")
            self._btn_mute.setStyleSheet(self._style_red())
        else:
            self._btn_mute.setText("Mic: LIVE")
            self._btn_mute.setStyleSheet(self._style_green())

    def _cb_tx_toggle(self, disabled):
        # Button checked = TX disabled
        if disabled:
            self.tx_gate.set_k((0+0j))
            self._btn_tx.setText("TX: DISABLED")
            self._btn_tx.setStyleSheet(self._style_red())
        else:
            self.tx_gate.set_k((1+0j))
            self._btn_tx.setText("TX: ENABLED")
            self._btn_tx.setStyleSheet(self._style_green())

    # =========================================================================
    #  Helpers
    # =========================================================================

    def closeEvent(self, event):
        self._level_timer.stop()
        self.stop()
        self.wait()
        event.accept()



# =============================================================================
#  Entry point
# =============================================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("OpenV2K")

    tb = VoicePulseTX()
    tb.show()
    tb.start()

    def _quit(sig=None, frame=None):
        tb.stop()
        tb.wait()
        app.quit()

    signal.signal(signal.SIGINT,  _quit)
    signal.signal(signal.SIGTERM, _quit)

    tick = QtCore.QTimer()
    tick.start(200)
    tick.timeout.connect(lambda: None)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
