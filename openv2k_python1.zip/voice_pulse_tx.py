#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# SPDX-License-Identifier: Unlicense
# This is free and unencumbered software released into the public domain.
#
# OpenV2K — Voice Zero-Crossing Pulse Transmitter
# ════════════════════════════════════════════════
# Captures microphone audio, conditions it for speech, detects every
# zero-crossing, and emits configurable-width pulses through a HackRF One.
#
# Requirements
# ────────────
#   sudo apt install gnuradio gr-osmosdr hackrf python3-pyqt5
#
# Usage
# ─────
#   python3 voice_pulse_tx.py
#
# Signal chain
# ────────────
#   Mic → DC Blocker → HPF → LPF → AGC → Zero-Cross Pulse
#       → Amplitude → Resampler (48k→2M) → Float→IQ → HackRF

import sys
import signal
import numpy as np

# ── GNU Radio imports ─────────────────────────────────────────────────────────
from gnuradio import gr, audio, analog, blocks
from gnuradio import filter as gr_filter      # shadows built-in; intentional
from gnuradio.filter import firdes

# GR 3.10 moved window constants into gnuradio.fft.window;
# fall back to the legacy firdes alias for older point releases.
try:
    from gnuradio.fft import window as gr_window
    _WIN_HAMMING = gr_window.WIN_HAMMING
except (ImportError, AttributeError):
    _WIN_HAMMING = firdes.WIN_HAMMING

import osmosdr

# ── Qt imports ────────────────────────────────────────────────────────────────
try:
    from PyQt5 import QtWidgets, QtCore, QtGui
except ImportError:
    sys.exit("PyQt5 required:  sudo apt install python3-pyqt5")


# ══════════════════════════════════════════════════════════════════════════════
#  Zero-Crossing Pulse Generator  (GNU Radio sync block)
# ══════════════════════════════════════════════════════════════════════════════

class ZeroCrossPulse(gr.sync_block):
    """
    Emits a 1.0 rectangular pulse of ``pulse_width_us`` microseconds on every
    zero-crossing (rising AND falling) of a float32 audio stream.
    Output is 1.0 during a pulse, 0.0 otherwise.

    Thread-safe callbacks
    ─────────────────────
    set_pulse_width_us(v)  — update pulse duration at runtime
    set_sample_rate(v)     — update sample rate at runtime
    """

    def __init__(self, sample_rate: float = 48_000.0,
                 pulse_width_us: float = 100.0):
        gr.sync_block.__init__(
            self, name="Zero Cross Pulse",
            in_sig=[np.float32], out_sig=[np.float32])
        self._sr    = float(sample_rate)
        self._pw_us = float(pulse_width_us)
        self._last  = 0.0
        self._rem   = 0
        self._recompute()

    # ── Callbacks ─────────────────────────────────────────────────────────

    def set_pulse_width_us(self, v: float) -> None:
        self._pw_us = float(v)
        self._recompute()

    def set_sample_rate(self, v: float) -> None:
        self._sr = float(v)
        self._recompute()

    # ── Internal ──────────────────────────────────────────────────────────

    def _recompute(self) -> None:
        self._plen = max(1, int(round(self._sr * self._pw_us * 1e-6)))

    # ── GNU Radio work loop ───────────────────────────────────────────────

    def work(self, input_items, output_items):
        in0, out        = input_items[0], output_items[0]
        last, rem, plen = self._last, self._rem, self._plen

        for i in range(len(in0)):
            curr = float(in0[i])
            # Rising edge: last < 0 and curr >= 0
            # Falling edge: last >= 0 and curr < 0
            if (last < 0.0 <= curr) or (last >= 0.0 > curr):
                rem = plen                  # (re-)arm pulse
            out[i] = 1.0 if rem > 0 else 0.0
            if rem > 0:
                rem -= 1
            last = curr

        self._last, self._rem = last, rem
        return len(in0)


# ══════════════════════════════════════════════════════════════════════════════
#  Labelled slider widget
# ══════════════════════════════════════════════════════════════════════════════

class LabelledSlider(QtWidgets.QWidget):
    """
    A horizontal QSlider with a fixed-width left label and a right readout.
    Operates on floating-point values; the underlying slider uses integer
    steps mapped from [lo, hi] with the given step size.
    """

    def __init__(self, label: str, lo: float, hi: float,
                 step: float, default: float,
                 fmt: str = "{:.1f}",
                 callback=None,
                 parent=None):
        super().__init__(parent)
        self._lo   = float(lo)
        self._step = float(step)
        self._fmt  = fmt
        self._cb   = callback

        n_steps = max(1, int(round((hi - lo) / step)))

        self._slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self._slider.setRange(0, n_steps)
        self._slider.setValue(int(round((default - lo) / step)))
        self._slider.setMinimumWidth(380)
        self._slider.setToolTip(f"{lo} – {hi}")

        self._readout = QtWidgets.QLabel(fmt.format(default))
        self._readout.setMinimumWidth(110)
        self._readout.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        self._readout.setFont(QtGui.QFont("Monospace", 9))

        lbl = QtWidgets.QLabel(f"<b>{label}</b>")
        lbl.setMinimumWidth(170)

        row = QtWidgets.QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        row.addWidget(lbl)
        row.addWidget(self._slider)
        row.addWidget(self._readout)

        self._slider.valueChanged.connect(self._on_change)

    def _on_change(self, pos: int) -> None:
        val = self._lo + pos * self._step
        self._readout.setText(self._fmt.format(val))
        if self._cb:
            self._cb(val)

    def value(self) -> float:
        return self._lo + self._slider.value() * self._step


# ══════════════════════════════════════════════════════════════════════════════
#  Top Block  (GNU Radio flow graph + Qt main window)
# ══════════════════════════════════════════════════════════════════════════════

class VoicePulseTX(gr.top_block, QtWidgets.QMainWindow):
    """
    GNU Radio top-block and Qt main window combined.
    All slider callbacks are safe to call while the flow graph is running.
    """

    # ── Compile-time constants ────────────────────────────────────────────
    AUDIO_RATE  = 48_000
    HACKRF_RATE = 2_000_000          # = 48 000 × 125 / 3  (exact)
    RESAMP_INTERP = 125
    RESAMP_DECIM  = 3

    def __init__(self):
        gr.top_block.__init__(self, "VoicePulseTX", catch_exceptions=True)
        QtWidgets.QMainWindow.__init__(self)

        self.setWindowTitle("OpenV2K — Voice Zero-Cross Pulse TX")
        self.setMinimumWidth(780)

        # ── Runtime parameters (modified by GUI sliders) ───────────────
        self._pulse_us  = 100.0
        self._hpf_hz    = 300.0
        self._lpf_hz    = 3_400.0
        self._freq_hz   = 433_920_000.0
        self._amplitude = 0.8

        self._build_gui()
        self._build_blocks()
        self._connect_blocks()

    # ══════════════════════════════════════════════════════════════════════
    #  GUI
    # ══════════════════════════════════════════════════════════════════════

    def _build_gui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        vbox = QtWidgets.QVBoxLayout(central)
        vbox.setContentsMargins(18, 18, 18, 18)
        vbox.setSpacing(10)

        # Title
        title = QtWidgets.QLabel(
            "<h2 style='color:#2a6ebb;'>OpenV2K</h2>"
            "<p style='margin:0;'>Voice Zero-Crossing Pulse Transmitter</p>")
        title.setAlignment(QtCore.Qt.AlignCenter)
        vbox.addWidget(title)

        vbox.addWidget(self._hline())

        # ── Signal processing controls ─────────────────────────────────
        vbox.addWidget(QtWidgets.QLabel(
            "<b>Signal Processing</b>"))

        self._sl_pulse = LabelledSlider(
            "Pulse Width (µs)", 50, 500, 5, self._pulse_us,
            fmt="{:.0f} µs", callback=self._cb_pulse)
        vbox.addWidget(self._sl_pulse)

        self._sl_hpf = LabelledSlider(
            "HPF Cutoff (Hz)", 250, 1_000, 10, self._hpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_hpf)
        vbox.addWidget(self._sl_hpf)

        self._sl_lpf = LabelledSlider(
            "LPF Cutoff (Hz)", 1_000, 15_000, 100, self._lpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_lpf)
        vbox.addWidget(self._sl_lpf)

        vbox.addWidget(self._hline())

        # ── Transmitter controls ───────────────────────────────────────
        vbox.addWidget(QtWidgets.QLabel(
            "<b>Transmitter</b>"))

        self._sl_freq = LabelledSlider(
            "Centre Freq (Hz)", 70e6, 6e9, 100e3, self._freq_hz,
            fmt="{:.0f} Hz", callback=self._cb_freq)
        vbox.addWidget(self._sl_freq)

        self._sl_amp = LabelledSlider(
            "TX Amplitude", 0.0, 1.0, 0.01, self._amplitude,
            fmt="{:.2f}", callback=self._cb_amp)
        vbox.addWidget(self._sl_amp)

        vbox.addWidget(self._hline())

        # ── Status bar ─────────────────────────────────────────────────
        self._status = QtWidgets.QLabel("● Initialising…")
        self._status.setStyleSheet("color: #888;")
        vbox.addWidget(self._status)

        vbox.addStretch()

    @staticmethod
    def _hline() -> QtWidgets.QFrame:
        f = QtWidgets.QFrame()
        f.setFrameShape(QtWidgets.QFrame.HLine)
        f.setFrameShadow(QtWidgets.QFrame.Sunken)
        return f

    # ══════════════════════════════════════════════════════════════════════
    #  GNU Radio blocks
    # ══════════════════════════════════════════════════════════════════════

    def _build_blocks(self):
        sr = self.AUDIO_RATE

        # 1. Microphone
        self.audio_src = audio.source(sr, "", True)

        # 2. DC blocker — removes DC offset that would bias zero-crossing
        self.dc_blocker = blocks.dc_blocker_ff(64, True)

        # 3. High-pass filter (variable cutoff)
        #    Default 300 Hz: removes room rumble, mains hum, wind noise
        self.hpf = gr_filter.fir_filter_fff(
            1,
            firdes.high_pass(
                1, sr, self._hpf_hz,
                transition_width=50,
                window=_WIN_HAMMING, param=6.76))

        # 4. Low-pass filter (variable cutoff)
        #    Default 3400 Hz: telephone-band upper limit; removes hiss
        self.lpf = gr_filter.fir_filter_fff(
            1,
            firdes.low_pass(
                1, sr, self._lpf_hz,
                transition_width=200,
                window=_WIN_HAMMING, param=6.76))

        # 5. AGC — normalises amplitude so all speakers produce consistent
        #    pulse density regardless of mic distance or input gain
        self.agc = analog.agc_ff(1e-4, 0.5, 1.0)
        self.agc.set_max_gain(65536)

        # 6. Zero-crossing pulse generator (custom block)
        self.zcp = ZeroCrossPulse(sr, self._pulse_us)

        # 7. Amplitude scaler
        self.mult = blocks.multiply_const_ff(self._amplitude)

        # 8. Rational resampler: 48 000 → 2 000 000 Hz
        #    (48 000 × 125 / 3 = 2 000 000 exactly — no rounding error)
        self.resampler = gr_filter.rational_resampler_fff(
            interpolation=self.RESAMP_INTERP,
            decimation=self.RESAMP_DECIM,
            taps=[],
            fractional_bw=0.0)

        # 9. Null source → imaginary (Q) channel = zero
        self.null_src = blocks.null_source(gr.sizeof_float)

        # 10. Float → Complex IQ (real pulse on I, zero on Q)
        self.f2c = blocks.float_to_complex(1)

        # 11. HackRF sink
        self.hackrf = osmosdr.sink(args="numchan=1 hackrf=0")
        self.hackrf.set_sample_rate(self.HACKRF_RATE)
        self.hackrf.set_center_freq(self._freq_hz, 0)
        self.hackrf.set_freq_corr(0, 0)
        self.hackrf.set_gain(0, 0)       # RF amp OFF (set to 14 to enable)
        self.hackrf.set_if_gain(40, 0)   # IF gain: 0–47 dB in 8 dB steps
        self.hackrf.set_bb_gain(20, 0)   # BB VGA gain: 0–62 dB in 2 dB steps
        self.hackrf.set_antenna("", 0)
        self.hackrf.set_bandwidth(0, 0)

    def _connect_blocks(self):
        """Wire the signal path."""
        self.connect(self.audio_src,  self.dc_blocker)
        self.connect(self.dc_blocker, self.hpf)
        self.connect(self.hpf,        self.lpf)
        self.connect(self.lpf,        self.agc)
        self.connect(self.agc,        self.zcp)
        self.connect(self.zcp,        self.mult)
        self.connect(self.mult,       self.resampler)
        self.connect(self.resampler,  (self.f2c, 0))   # I (real) channel
        self.connect(self.null_src,   (self.f2c, 1))   # Q (imaginary) = 0
        self.connect(self.f2c,        self.hackrf)

    # ══════════════════════════════════════════════════════════════════════
    #  Slider callbacks  (called on the Qt thread; GNU Radio is thread-safe
    #  for set_taps / set_k / set_center_freq via the GIL)
    # ══════════════════════════════════════════════════════════════════════

    def _cb_pulse(self, v: float) -> None:
        self._pulse_us = v
        self.zcp.set_pulse_width_us(v)

    def _cb_hpf(self, v: float) -> None:
        self._hpf_hz = v
        self.hpf.set_taps(firdes.high_pass(
            1, self.AUDIO_RATE, v,
            transition_width=50,
            window=_WIN_HAMMING, param=6.76))

    def _cb_lpf(self, v: float) -> None:
        self._lpf_hz = v
        self.lpf.set_taps(firdes.low_pass(
            1, self.AUDIO_RATE, v,
            transition_width=200,
            window=_WIN_HAMMING, param=6.76))

    def _cb_freq(self, v: float) -> None:
        self._freq_hz = v
        self.hackrf.set_center_freq(v, 0)

    def _cb_amp(self, v: float) -> None:
        self._amplitude = v
        self.mult.set_k(v)

    # ── Helpers ───────────────────────────────────────────────────────────

    def set_status(self, text: str) -> None:
        colour = "#2a6ebb" if "Running" in text else \
                 "#c0392b" if "Stop" in text else "#888"
        self._status.setStyleSheet(f"color: {colour};")
        self._status.setText(text)

    def closeEvent(self, event):
        """Clean shutdown when the window is closed."""
        self.stop()
        self.wait()
        event.accept()


# ══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("OpenV2K")

    tb = VoicePulseTX()
    tb.show()
    tb.start()
    tb.set_status("● Running")

    def _quit(sig=None, frame=None):
        tb.set_status("● Stopping…")
        tb.stop()
        tb.wait()
        app.quit()

    signal.signal(signal.SIGINT,  _quit)
    signal.signal(signal.SIGTERM, _quit)

    # QTimer keeps the Python event loop alive so Ctrl-C works
    tick = QtCore.QTimer()
    tick.start(200)
    tick.timeout.connect(lambda: None)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
