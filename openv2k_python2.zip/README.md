# OpenV2K — Voice Zero-Crossing Pulse Transmitter

**Public Domain / Unlicense — Free, Open-Source Software**

Captures microphone audio, conditions it for human speech, detects every
zero-crossing, and emits a configurable-width pulse stream through a
HackRF One SDR via gr-osmosdr.

---

## Files

| File | Purpose |
|---|---|
| `voice_pulse_tx.py` | **Main application** — run this directly |
| `zero_cross_pulse.py` | Standalone GNU Radio block (also embedded in the main script) |

---

## Requirements

```bash
sudo apt install gnuradio gr-osmosdr hackrf python3-pyqt5
```

Verify everything is working:

```bash
python3 -c "from gnuradio import gr; print(gr.version())"
python3 -c "import osmosdr; print('gr-osmosdr OK')"
hackrf_info    # with HackRF plugged in
```

---

## HackRF udev rule (one-time setup)

Allows HackRF access without sudo:

```bash
echo 'SUBSYSTEM=="usb", ATTRS{idVendor}=="1d50", ATTRS{idProduct}=="6089", MODE="0666", GROUP="plugdev"' \
  | sudo tee /etc/udev/rules.d/53-hackrf.rules
sudo udevadm control --reload-rules && sudo udevadm trigger
sudo usermod -aG plugdev $USER
# Log out and back in for the group change to take effect
```

---

## Running

```bash
python3 voice_pulse_tx.py
```

Plug in your HackRF before running. The app will exit with an error if no
HackRF is found.

---

## Signal Chain

```
Mic
 │
 ▼
DC Blocker (64-tap IIR)
 │  Removes DC offset and mic drift that would bias zero-crossing detection
 │
 ▼
High-Pass FIR ◄── GUI slider: 250–1 000 Hz (default 300 Hz)
 │  Removes: room rumble, wind noise, mains hum, plosive breath blasts
 │
 ▼
Low-Pass FIR  ◄── GUI slider: 1 000–15 000 Hz (default 3 400 Hz)
 │  Removes: hiss, sibilance, aliasing noise above the voice band
 │
 ▼
AGC (analog_agc_ff)
 │  Keeps amplitude constant; loop rate 1e-4 → ~100 ms response
 │
 ▼
Zero-Cross Pulse Generator ◄── GUI slider: 50–500 µs (default 100 µs)
 │  Emits a 1.0 pulse at every sign change of the conditioned voice signal
 │
 ▼
Multiply Const ◄── GUI slider: 0.00–1.00 (TX amplitude)
 │
 ▼
Rational Resampler  interp=125 / decim=3
 │  48 000 × 125 / 3 = 2 000 000 Hz exactly
 │
 ▼
Float → Complex  (null source on Q channel → pure real signal)
 │
 ▼
HackRF Sink (osmosdr)  ◄── GUI slider: centre frequency
 │  RF amp OFF, IF gain 40 dB, BB gain 20 dB
```

---

## GUI Controls

| Slider | Range | Default | Effect |
|---|---|---|---|
| Pulse Width (µs) | 50–500 | 100 | Duration of each zero-crossing pulse |
| HPF Cutoff (Hz) | 250–1 000 | 300 | High-pass voice floor |
| LPF Cutoff (Hz) | 1 000–15 000 | 3 400 | Low-pass voice ceiling |
| Centre Freq (Hz) | 70 MHz–6 GHz | 433.92 MHz | HackRF carrier |
| TX Amplitude | 0.00–1.00 | 0.80 | Output signal scale |

---

## Recommended Additional Filters

These can be added to the Python signal chain with minimal effort:

### 1. Squelch / Noise Gate
```python
# After the AGC, before the zero-cross pulse block
self.squelch = analog.simple_squelch_cc(threshold_dB=-30, alpha=0.001)
```
Silences output when the speaker is not talking, preventing spurious pulses
from ambient noise. Adjust threshold_dB to sit just above the noise floor.

### 2. Pre-emphasis shelf (+6 dB/octave above ~1 kHz)
Boosts consonants and increases zero-crossing density in the higher harmonics.
```python
from scipy.signal import iirfilter
# Single-pole shelving filter at 1 kHz, 48 kHz sample rate
b = [1.0, -0.9375]
a = [1.0]
self.pre_emph = gr_filter.iir_filter_ffd(b, a, False)
```

### 3. Biquad IIR notch at mains frequency
More efficient than a wide FIR band-reject for 50/60 Hz hum:
```python
from scipy.signal import iirnotch
b, a = iirnotch(60, Q=30, fs=48000)   # change 60 → 50 for European mains
self.notch = gr_filter.iir_filter_ffd(b.tolist(), a.tolist(), False)
```

### 4. Spectral subtraction noise reducer
For noisy environments: estimate noise floor during silence, subtract in FFT
domain. Requires a custom `gr.sync_block` using `numpy.fft`.

---

## HackRF Gain Settings

| Parameter | Default | Notes |
|---|---|---|
| RF Amp | 0 (off) | Set to 14 to enable; adds noise — leave off unless needed |
| IF Gain | 40 dB | Valid steps: 0 8 16 24 32 40 (steps of 8) |
| BB Gain | 20 dB | Fine control: 0–62 dB in steps of 2 |

Start at RF=0, IF=40, BB=20. Reduce BB if you see inter-modulation distortion.

---

## Pulse Width vs. Voice Frequency

At 48 kHz sample rate, approximate spectral content:

| Pulse Width | Samples | Nyquist limit |
|---|---|---|
| 50 µs | 2–3 | ~24 000 Hz |
| 100 µs | 4–5 | ~10 000 Hz |
| 200 µs | 9–10 | ~5 000 Hz |
| 500 µs | 24 | ~2 000 Hz |

For voice (300–3 400 Hz), 100–200 µs is a good starting range.

---

## Troubleshooting

**No audio input**: Check system default microphone.
Change `audio.source(sr, "", True)` — replace `""` with your ALSA device name,
e.g. `"hw:0,0"`.

```bash
arecord -l    # list capture devices
```

**HackRF not found at startup**: Ensure `hackrf_info` works first.
Check the udev rule and plugdev group membership. Unplug/replug after
setting the rule.

**`ImportError: No module named osmosdr`**:
```bash
sudo apt install gr-osmosdr
```

**Audio dropouts / buffer overruns**: Lower the system audio buffer size or
set GNU Radio thread priority:
```bash
sudo sysctl -w kernel.sched_rt_runtime_us=-1
```

**Filter sounds wrong after moving slider**: The FIR filter tap count
changes with cutoff frequency. If you hear a glitch when moving the HPF/LPF
sliders, that is normal — the filter is being reloaded mid-stream.

---

## License

This is free and unencumbered software released into the public domain
under the [Unlicense](https://unlicense.org).

To the extent possible under law, the author(s) have dedicated all copyright
and related and neighboring rights to this software to the public domain
worldwide. This software is distributed without any warranty.
