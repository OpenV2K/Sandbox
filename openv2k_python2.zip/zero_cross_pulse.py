#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zero_cross_pulse.py  –  GNU Radio custom sync block
====================================================
Detects every zero-crossing of a real-valued audio stream and emits a
rectangular pulse of configurable width at each event.

Can be used two ways
--------------------
1.  Drop this file into the same directory as your .grc flowgraph and
    import it as a module block  (import zero_cross_pulse).
2.  Paste the blk class verbatim into a GRC "Embedded Python Block"
    (epy_block) – GRC requires the class to be named  blk.

Parameters (exposed to GRC via set_* callbacks)
------------------------------------------------
sample_rate     : float  – must match the upstream audio sample rate (Hz)
pulse_width_us  : float  – pulse duration in microseconds  [50 – 500]
"""

import numpy as np
from gnuradio import gr


# ---------------------------------------------------------------------------
# Main block
# ---------------------------------------------------------------------------

class zero_cross_pulse(gr.sync_block):
    """
    Zero-Crossing Pulse Generator

    On every transition of the input signal through zero (rising *or*
    falling), a rectangular pulse of ``pulse_width_us`` microseconds is
    written to the output stream.  The output is 1.0 during a pulse and
    0.0 otherwise.
    """

    def __init__(
        self,
        sample_rate: float = 48_000.0,
        pulse_width_us: float = 100.0,
    ):
        gr.sync_block.__init__(
            self,
            name="Zero Cross Pulse",
            in_sig=[np.float32],
            out_sig=[np.float32],
        )

        self._sr = float(sample_rate)
        self._pw_us = float(pulse_width_us)

        # State carried across work() calls
        self._last_sample: float = 0.0
        self._remain: int = 0

        self._recompute()

    # ------------------------------------------------------------------
    # GRC variable callbacks  (called automatically when GUI widgets
    # change the corresponding flowgraph variable)
    # ------------------------------------------------------------------

    def set_pulse_width_us(self, pulse_width_us: float) -> None:
        """Update pulse width at runtime (thread-safe via the GIL)."""
        self._pw_us = float(pulse_width_us)
        self._recompute()

    def set_sample_rate(self, sample_rate: float) -> None:
        """Update sample rate at runtime."""
        self._sr = float(sample_rate)
        self._recompute()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _recompute(self) -> None:
        """Convert µs pulse width to whole samples."""
        samples = self._sr * self._pw_us * 1e-6
        self._pulse_len = max(1, int(round(samples)))

    # ------------------------------------------------------------------
    # GNU Radio work function  (called repeatedly by the scheduler)
    # ------------------------------------------------------------------

    def work(self, input_items, output_items):  # noqa: D102
        in0 = input_items[0]
        out = output_items[0]

        # Local copies for speed  (avoids repeated attribute look-ups)
        last   = self._last_sample
        remain = self._remain
        plen   = self._pulse_len

        for i in range(len(in0)):
            curr = float(in0[i])

            # ── Zero-crossing detection ──────────────────────────────
            #   Rising  edge : last <  0  and  curr >= 0
            #   Falling edge : last >= 0  and  curr <  0
            if (last < 0.0 <= curr) or (last >= 0.0 > curr):
                remain = plen          # (re-)arm the pulse

            # ── Pulse output ─────────────────────────────────────────
            if remain > 0:
                out[i] = 1.0
                remain -= 1
            else:
                out[i] = 0.0

            last = curr

        # Save state for the next call
        self._last_sample = last
        self._remain      = remain

        return len(in0)


# ---------------------------------------------------------------------------
# Alias required by GRC epy_block  (the embedded class MUST be named 'blk')
# ---------------------------------------------------------------------------
blk = zero_cross_pulse
