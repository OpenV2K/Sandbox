#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# SPDX-License-Identifier: Unlicense
# This is free and unencumbered software released into the public domain.
#
# OpenV2K -- Voice Zero-Crossing Pulse Transmitter
# =================================================
# Captures microphone audio, conditions it for speech, detects every
# zero-crossing, and emits configurable-width pulses through a HackRF One.
#
# Requirements:
#   sudo apt install gnuradio gr-osmosdr hackrf python3-pyqt5
#
# Usage:
#   python3 voice_pulse_tx.py
#
# Signal chain:
#   Mic -> Mute Gate -> DC Blocker -> HPF -> LPF -> AGC
#       -> Zero-Cross Pulse -> Amplitude -> Resampler (48k->2M)
#       -> Float->IQ -> TX Gate -> HackRF

import sys
import signal
import numpy as np

# -- GNU Radio imports --------------------------------------------------------
from gnuradio import gr, audio, analog, blocks
from gnuradio import filter as gr_filter
from gnuradio.filter import firdes

try:
    from gnuradio.fft import window as gr_window
    _WIN_HAMMING = gr_window.WIN_HAMMING
except (ImportError, AttributeError):
    _WIN_HAMMING = firdes.WIN_HAMMING

import osmosdr

# -- Qt imports ---------------------------------------------------------------
try:
    from PyQt5 import QtWidgets, QtCore, QtGui
except ImportError:
    sys.exit("PyQt5 required: sudo apt install python3-pyqt5")


# =============================================================================
#  Zero-Crossing Pulse Generator (GNU Radio sync block)
# =============================================================================

class ZeroCrossPulse(gr.sync_block):
    """
    Emits a 1.0 pulse of pulse_width_us microseconds on every zero-crossing
    (rising AND falling) of a float32 audio stream.
    Output is 1.0 during a pulse, 0.0 otherwise.
    """

    def __init__(self, sample_rate=48000.0, pulse_width_us=100.0):
        gr.sync_block.__init__(
            self, name="Zero Cross Pulse",
            in_sig=[np.float32], out_sig=[np.float32])
        self._sr    = float(sample_rate)
        self._pw_us = float(pulse_width_us)
        self._last  = 0.0
        self._rem   = 0
        self._recompute()

    def set_pulse_width_us(self, v):
        self._pw_us = float(v)
        self._recompute()

    def set_sample_rate(self, v):
        self._sr = float(v)
        self._recompute()

    def _recompute(self):
        self._plen = max(1, int(round(self._sr * self._pw_us * 1e-6)))

    def work(self, input_items, output_items):
        in0, out        = input_items[0], output_items[0]
        last, rem, plen = self._last, self._rem, self._plen
        for i in range(len(in0)):
            curr = float(in0[i])
            if (last < 0.0 <= curr) or (last >= 0.0 > curr):
                rem = plen
            out[i] = 1.0 if rem > 0 else 0.0
            if rem > 0:
                rem -= 1
            last = curr
        self._last, self._rem = last, rem
        return len(in0)


# =============================================================================
#  Labelled slider widget with tick marks
# =============================================================================

class LabelledSlider(QtWidgets.QWidget):
    """
    Compact horizontal slider with label, tick marks, and readout.
    tick_steps: number of slider integer steps between each visible tick.
    """

    def __init__(self, label, lo, hi, step, default,
                 fmt="{:.0f}", callback=None, tick_steps=10, parent=None):
        super().__init__(parent)
        self._lo   = float(lo)
        self._step = float(step)
        self._fmt  = fmt
        self._cb   = callback

        n_steps = max(1, int(round((hi - lo) / step)))

        self._slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self._slider.setRange(0, n_steps)
        self._slider.setValue(int(round((default - lo) / step)))
        self._slider.setMinimumWidth(160)
        self._slider.setMaximumWidth(220)
        self._slider.setTickPosition(QtWidgets.QSlider.TicksBelow)
        self._slider.setTickInterval(tick_steps)
        self._slider.setToolTip("{} - {}".format(lo, hi))

        self._readout = QtWidgets.QLabel(fmt.format(default))
        self._readout.setMinimumWidth(72)
        self._readout.setAlignment(
            QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        self._readout.setFont(QtGui.QFont("Monospace", 8))

        lbl = QtWidgets.QLabel("<b>{}</b>".format(label))
        lbl.setMinimumWidth(100)
        lbl.setMaximumWidth(110)

        row = QtWidgets.QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        row.addWidget(lbl)
        row.addWidget(self._slider)
        row.addWidget(self._readout)

        self._slider.valueChanged.connect(self._on_change)

    def _on_change(self, pos):
        val = self._lo + pos * self._step
        self._readout.setText(self._fmt.format(val))
        if self._cb:
            self._cb(val)

    def value(self):
        return self._lo + self._slider.value() * self._step


# =============================================================================
#  Top Block (GNU Radio flow graph + Qt main window)
# =============================================================================

class VoicePulseTX(gr.top_block, QtWidgets.QMainWindow):
    """
    GNU Radio top-block and Qt main window combined.
    All callbacks are safe to call while the flow graph is running.
    """

    # -- Constants ------------------------------------------------------------
    AUDIO_RATE    = 48000
    HACKRF_RATE   = 2000000     # 48000 * 125 / 3 = 2000000 exactly
    RESAMP_INTERP = 125
    RESAMP_DECIM  = 3

    # Frequency options (Hz)
    FREQ_70CM  = 425e6           # 70cm UHF amateur band
    FREQ_23CM  = 1300e6          # 23cm amateur band / L-band

    # Power options
    # Power is proportional to amplitude squared.
    # AMP_2MW = sqrt(2) * AMP_1MW  so that P_2MW = 2 * P_1MW (relative).
    AMP_1MW = 0.500
    AMP_2MW = 0.707

    def __init__(self):
        gr.top_block.__init__(self, "VoicePulseTX", catch_exceptions=True)
        QtWidgets.QMainWindow.__init__(self)

        self.setWindowTitle("OpenV2K -- Voice Zero-Cross Pulse TX")
        self.setFixedWidth(440)

        # -- Runtime state ----------------------------------------------------
        self._pulse_us   = 100.0
        self._hpf_hz     = 300.0
        self._lpf_hz     = 3400.0
        self._freq_hz    = self.FREQ_23CM   # default 1.3 GHz
        self._amplitude  = self.AMP_1MW
        self._muted      = False
        self._tx_enabled = True

        self._build_gui()
        self._build_blocks()
        self._connect_blocks()

    # =========================================================================
    #  GUI
    # =========================================================================

    def _build_gui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        vbox = QtWidgets.QVBoxLayout(central)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(8)

        # Title
        title = QtWidgets.QLabel(
            "<h3 style='color:#2a6ebb; margin:0;'>OpenV2K</h3>"
            "<small>Voice Zero-Crossing Pulse TX</small>")
        title.setAlignment(QtCore.Qt.AlignCenter)
        vbox.addWidget(title)
        vbox.addWidget(self._hline())

        # -----------------------------------------------------------------
        # Signal Processing section
        # -----------------------------------------------------------------
        vbox.addWidget(QtWidgets.QLabel("<b>Signal Processing</b>"))

        # Pulse width: 50-500 us, step 5 us, tick every 50 us (10 steps)
        self._sl_pulse = LabelledSlider(
            "Pulse (us)", 50, 500, 5, self._pulse_us,
            fmt="{:.0f} us", callback=self._cb_pulse, tick_steps=10)
        vbox.addWidget(self._sl_pulse)

        # HPF: 250-1000 Hz, step 10 Hz, tick every 100 Hz (10 steps)
        self._sl_hpf = LabelledSlider(
            "HPF (Hz)", 250, 1000, 10, self._hpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_hpf, tick_steps=10)
        vbox.addWidget(self._sl_hpf)

        # LPF: 1000-15000 Hz, step 100 Hz, tick every 500 Hz (5 steps)
        self._sl_lpf = LabelledSlider(
            "LPF (Hz)", 1000, 15000, 100, self._lpf_hz,
            fmt="{:.0f} Hz", callback=self._cb_lpf, tick_steps=5)
        vbox.addWidget(self._sl_lpf)

        vbox.addWidget(self._hline())

        # -----------------------------------------------------------------
        # Transmitter section
        # -----------------------------------------------------------------
        vbox.addWidget(QtWidgets.QLabel("<b>Transmitter</b>"))

        # Frequency toggle
        freq_box = QtWidgets.QGroupBox("Frequency")
        freq_layout = QtWidgets.QHBoxLayout()
        freq_layout.setSpacing(8)
        self._rb_70cm = QtWidgets.QRadioButton("425 MHz (70cm)")
        self._rb_23cm = QtWidgets.QRadioButton("1300 MHz (23cm)")
        self._rb_23cm.setChecked(True)
        self._rb_70cm.toggled.connect(self._cb_freq_toggle)
        freq_layout.addWidget(self._rb_70cm)
        freq_layout.addWidget(self._rb_23cm)
        freq_box.setLayout(freq_layout)
        vbox.addWidget(freq_box)

        # Power toggle
        pwr_box = QtWidgets.QGroupBox("TX Power (relative)")
        pwr_layout = QtWidgets.QHBoxLayout()
        pwr_layout.setSpacing(8)
        self._rb_1mw = QtWidgets.QRadioButton("1 mW")
        self._rb_2mw = QtWidgets.QRadioButton("2 mW")
        self._rb_1mw.setChecked(True)
        self._rb_1mw.toggled.connect(self._cb_pwr_toggle)
        pwr_layout.addWidget(self._rb_1mw)
        pwr_layout.addWidget(self._rb_2mw)
        pwr_box.setLayout(pwr_layout)
        vbox.addWidget(pwr_box)

        # Mute button
        self._btn_mute = QtWidgets.QPushButton("Mic: LIVE")
        self._btn_mute.setCheckable(True)
        self._btn_mute.setChecked(False)
        self._btn_mute.setMinimumHeight(36)
        self._btn_mute.setStyleSheet(self._style_green())
        self._btn_mute.toggled.connect(self._cb_mute)
        vbox.addWidget(self._btn_mute)

        # TX enable button
        self._btn_tx = QtWidgets.QPushButton("TX: ENABLED")
        self._btn_tx.setCheckable(True)
        self._btn_tx.setChecked(False)
        self._btn_tx.setMinimumHeight(36)
        self._btn_tx.setStyleSheet(self._style_green())
        self._btn_tx.toggled.connect(self._cb_tx_toggle)
        vbox.addWidget(self._btn_tx)

        vbox.addWidget(self._hline())

        # Status
        self._status = QtWidgets.QLabel("* Initialising...")
        self._status.setStyleSheet("color: #888; font-size: 10px;")
        vbox.addWidget(self._status)
        vbox.addStretch()

    # -- Style helpers --------------------------------------------------------

    @staticmethod
    def _style_green():
        return ("QPushButton { background-color: #27ae60; color: white; "
                "border-radius: 4px; font-weight: bold; }"
                "QPushButton:hover { background-color: #2ecc71; }")

    @staticmethod
    def _style_red():
        return ("QPushButton { background-color: #c0392b; color: white; "
                "border-radius: 4px; font-weight: bold; }"
                "QPushButton:hover { background-color: #e74c3c; }")

    @staticmethod
    def _hline():
        f = QtWidgets.QFrame()
        f.setFrameShape(QtWidgets.QFrame.HLine)
        f.setFrameShadow(QtWidgets.QFrame.Sunken)
        return f

    # =========================================================================
    #  GNU Radio blocks
    # =========================================================================

    def _build_blocks(self):
        sr = self.AUDIO_RATE

        # 1. Microphone
        self.audio_src = audio.source(sr, "", True)

        # 2. Mute gate -- set_k(0.0) silences input, set_k(1.0) passes it
        self.mute_gate = blocks.multiply_const_ff(1.0)

        # 3. DC blocker IIR -- H(z) = (1 - z^-1) / (1 - 0.999*z^-1)
        #    Removes DC offset without disturbing voice frequencies
        #    fftaps = feedforward (numerator)
        #    fbtaps = feedback denominator (oldstyle=True, excludes leading 1)
        self.dc_blocker = gr_filter.iir_filter_ffd(
            [1.0, -1.0],
            [-0.999],
            True)

        # 4. High-pass filter (variable cutoff via slider)
        #    Default 300 Hz: removes rumble, mains hum, wind, plosives
        self.hpf = gr_filter.fir_filter_fff(
            1,
            firdes.high_pass(
                1, sr, self._hpf_hz,
                transition_width=50,
                window=_WIN_HAMMING, param=6.76))

        # 5. Low-pass filter (variable cutoff via slider)
        #    Default 3400 Hz: telephone band ceiling, removes hiss
        self.lpf = gr_filter.fir_filter_fff(
            1,
            firdes.low_pass(
                1, sr, self._lpf_hz,
                transition_width=200,
                window=_WIN_HAMMING, param=6.76))

        # 6. AGC -- normalises amplitude regardless of mic level
        self.agc = analog.agc_ff(1e-4, 0.5, 1.0)
        self.agc.set_max_gain(65536)

        # 7. Zero-crossing pulse generator
        self.zcp = ZeroCrossPulse(sr, self._pulse_us)

        # 8. Amplitude scaler
        self.mult = blocks.multiply_const_ff(self._amplitude)

        # 9. Rational resampler: 48000 -> 2000000 Hz (125/3, exact)
        self.resampler = gr_filter.rational_resampler_fff(
            interpolation=self.RESAMP_INTERP,
            decimation=self.RESAMP_DECIM,
            taps=[],
            fractional_bw=0.0)

        # 10. Null source for Q (imaginary) channel
        self.null_src = blocks.null_source(gr.sizeof_float)

        # 11. Float -> Complex IQ
        self.f2c = blocks.float_to_complex(1)

        # 12. TX gate -- set_k(0+0j) zeros the IQ stream (silent carrier)
        #     set_k(1+0j) passes the pulse stream through
        self.tx_gate = blocks.multiply_const_cc((1+0j))

        # 13. HackRF sink
        self.hackrf = osmosdr.sink(args="numchan=1 hackrf=0")
        self.hackrf.set_sample_rate(self.HACKRF_RATE)
        self.hackrf.set_center_freq(self._freq_hz, 0)
        self.hackrf.set_freq_corr(0, 0)
        self.hackrf.set_gain(0, 0)       # RF amp OFF
        self.hackrf.set_if_gain(40, 0)   # IF gain: 0-47 dB in 8 dB steps
        self.hackrf.set_bb_gain(20, 0)   # BB VGA: 0-62 dB in 2 dB steps
        self.hackrf.set_antenna("", 0)
        self.hackrf.set_bandwidth(0, 0)

    def _connect_blocks(self):
        self.connect(self.audio_src,  self.mute_gate)
        self.connect(self.mute_gate,  self.dc_blocker)
        self.connect(self.dc_blocker, self.hpf)
        self.connect(self.hpf,        self.lpf)
        self.connect(self.lpf,        self.agc)
        self.connect(self.agc,        self.zcp)
        self.connect(self.zcp,        self.mult)
        self.connect(self.mult,       self.resampler)
        self.connect(self.resampler,  (self.f2c, 0))
        self.connect(self.null_src,   (self.f2c, 1))
        self.connect(self.f2c,        self.tx_gate)
        self.connect(self.tx_gate,    self.hackrf)

    # =========================================================================
    #  Slider callbacks
    # =========================================================================

    def _cb_pulse(self, v):
        self._pulse_us = v
        self.zcp.set_pulse_width_us(v)

    def _cb_hpf(self, v):
        self._hpf_hz = v
        self.hpf.set_taps(firdes.high_pass(
            1, self.AUDIO_RATE, v,
            transition_width=50,
            window=_WIN_HAMMING, param=6.76))

    def _cb_lpf(self, v):
        self._lpf_hz = v
        self.lpf.set_taps(firdes.low_pass(
            1, self.AUDIO_RATE, v,
            transition_width=200,
            window=_WIN_HAMMING, param=6.76))

    # =========================================================================
    #  Toggle callbacks
    # =========================================================================

    def _cb_freq_toggle(self, is_70cm):
        """Radio button: 70cm selected = True, 23cm selected = False."""
        self._freq_hz = self.FREQ_70CM if is_70cm else self.FREQ_23CM
        self.hackrf.set_center_freq(self._freq_hz, 0)

    def _cb_pwr_toggle(self, is_1mw):
        """Radio button: 1mW selected = True, 2mW selected = False."""
        self._amplitude = self.AMP_1MW if is_1mw else self.AMP_2MW
        self.mult.set_k(self._amplitude)

    def _cb_mute(self, muted):
        """Toggle button: checked = muted."""
        self._muted = muted
        self.mute_gate.set_k(0.0 if muted else 1.0)
        if muted:
            self._btn_mute.setText("Mic: MUTED")
            self._btn_mute.setStyleSheet(self._style_red())
        else:
            self._btn_mute.setText("Mic: LIVE")
            self._btn_mute.setStyleSheet(self._style_green())

    def _cb_tx_toggle(self, disabled):
        """Toggle button: checked = TX disabled."""
        if disabled:
            self.tx_gate.set_k((0+0j))
            self._btn_tx.setText("TX: DISABLED")
            self._btn_tx.setStyleSheet(self._style_red())
        else:
            self.tx_gate.set_k((1+0j))
            self._btn_tx.setText("TX: ENABLED")
            self._btn_tx.setStyleSheet(self._style_green())

    # =========================================================================
    #  Helpers
    # =========================================================================

    def set_status(self, text):
        colour = "#27ae60" if "Running" in text else \
                 "#c0392b" if "Stop" in text else "#888"
        self._status.setStyleSheet(
            "color: {}; font-size: 10px;".format(colour))
        self._status.setText(text)

    def closeEvent(self, event):
        self.stop()
        self.wait()
        event.accept()


# =============================================================================
#  Entry point
# =============================================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("OpenV2K")

    tb = VoicePulseTX()
    tb.show()
    tb.start()
    tb.set_status("* Running")

    def _quit(sig=None, frame=None):
        tb.set_status("* Stopping...")
        tb.stop()
        tb.wait()
        app.quit()

    signal.signal(signal.SIGINT,  _quit)
    signal.signal(signal.SIGTERM, _quit)

    tick = QtCore.QTimer()
    tick.start(200)
    tick.timeout.connect(lambda: None)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
